#include <quaternion.h>
#define QUAT_primality_num_iter 32
#define QUAT_repres_bound_input 20
#define QUAT_equiv_bound_coeff 64
#define QUAT_good_prime_lists_length 101
#define QUAT_qlapoti_gen_bound_bits 17
#define QUAT_qlapoti_used_power_of_two 246
#define QUAT_qlapoti_iteration_bound 20000
#define FINDUV_box_size 2
#define FINDUV_cube_size 624
