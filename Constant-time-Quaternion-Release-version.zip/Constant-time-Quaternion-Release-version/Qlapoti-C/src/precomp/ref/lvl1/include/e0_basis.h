#include <fp2.h>
extern const fp2_t BASIS_E0_PX;
extern const fp2_t BASIS_E0_QX;
