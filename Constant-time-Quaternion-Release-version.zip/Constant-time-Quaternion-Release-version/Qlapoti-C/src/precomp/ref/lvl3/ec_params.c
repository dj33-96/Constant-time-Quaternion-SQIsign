#include <ec_params.h>
// p+1 divided by the power of 2
const digit_t p_cofactor_for_2f[1] = {65};

