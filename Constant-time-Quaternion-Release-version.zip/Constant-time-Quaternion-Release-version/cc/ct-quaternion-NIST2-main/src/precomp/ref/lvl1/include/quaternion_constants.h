#include <quaternion.h>
#define QUAT_primality_num_iter 32
#define QUAT_repres_bound_input 20
#define QUAT_equiv_bound_coeff 64
#define FINDUV_box_size 2
#define FINDUV_cube_size 624
